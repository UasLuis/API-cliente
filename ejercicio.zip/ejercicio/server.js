const express = require('express');
const fs = require('fs');
const app = express();
const port = 3000;

app.listen(port, () => {
  console.log('Servicio iniciado en:', port);
});

app.get('/creditos', (req, res) => {
    const creditos = fs.readFileSync('data.json');
    const data = JSON.parse(creditos);
    res.json(data);
});

app.get('/creditos/:importe', (req, res) => {
    const { importe } = req.params;
    const contenido = fs.readFileSync('data.json');
    const data = JSON.parse(contenido);

    const importeNumero = Number(importe);

    const encontrados = data.filter((x) =>
        x.activo === true && x.credito > importeNumero
    );

    if (encontrados.length === 0) {
        res.status(404).json({ mensaje: "No encontrado" });
    } else {
        res.json(encontrados);
    }
});

app.get('/creditos-cliente/:id', (req, res) => {
    const { id } = req.params;
    const contenido = fs.readFileSync('data.json');
    const data = JSON.parse(contenido);

    const encontrados = data.filter((x) => x.id == id);

    if (encontrados.length === 0) {
        res.status(404).json({ mensaje: "No encontrado" });
    } else {
        res.json(encontrados);
    }
});
